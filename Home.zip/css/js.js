var slides = document.querySelectorAll('.slider img');
        var textContainers = document.querySelectorAll('.text-container');
        var currentSlide = 0;
        var slideInterval = setInterval(nextSlide, 2000);

        function nextSlide() {
            if (currentSlide === slides.length - 1) {
                document.querySelector('.slider').style.transition = 'none';
                currentSlide = 0;
            } else {
                document.querySelector('.slider').style.transition = 'transform 0.5s ease';
                currentSlide++;
            }
            document.querySelector('.slider').style.transform = 'translateX(' + (currentSlide * -20) + '%)';
            
            textContainers.forEach(function(container) {
                container.classList.remove('active');
            });
            
            textContainers[currentSlide].classList.add('active');
        }