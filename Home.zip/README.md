# Web Technology Assignment 2
We are creating a webpage with e-commerce integration using HTML, CSS, and JavaScript technologies.
